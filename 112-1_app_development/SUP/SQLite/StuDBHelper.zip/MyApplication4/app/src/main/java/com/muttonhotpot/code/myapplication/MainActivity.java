package com.muttonhotpot.code.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    SQLiteDatabase db;
    StdDBHelper dbHelper;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = findViewById(R.id.lblOutput);
    }

    public void btnClickI(View view) {
        dbHelper = new StdDBHelper(this);
        db = dbHelper.getWritableDatabase();
        tv.setText("is db connection open? " + db.isOpen() + "\nDB version: " + db.getVersion());

    }

    public void btnUpgrade(View view) {
        dbHelper = new StdDBHelper(this);
        db = dbHelper.getWritableDatabase();
        dbHelper.onUpgrade(db, 0, 0);
        tv.setText("Db upgraded done!" + db.isOpen() + "\nDB version: " + db.getVersion());

    }

}