Change Log
==========
Version 0.1.4 *(2021-01-16)*
----------------------------
Dependencies updated.
Using KRecyclerFragment from KUtil library. 

Version 0.1.3 *(2021-01-16)*
----------------------------
Layout renamed to avoid view binding conflict.

Version 0.1.2 *(2021-01-07)*
----------------------------
Layout managers added.
Some bugs fixed.

Version 0.1.1 *(2021-01-06)*
----------------------------
Structural library bug fixed.

Version 0.1.0 *(2021-01-06)*
----------------------------
Initial release.